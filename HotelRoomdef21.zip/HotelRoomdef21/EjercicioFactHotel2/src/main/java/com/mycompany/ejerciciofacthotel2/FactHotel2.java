/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejerciciofacthotel2;




public class FactHotel2 {

    public static void main(String[] args) {
         Facture Fact = new Facture();
         String val;
        
        do{

        Fact.dataCollection();
        Fact.printFacture();
        val=Fact.continuefact();
       
                
        }while(val.equals("1"));
        System.out.println("huespedes respistrados: ");
       for (String reservation : Fact.getReservation()) {
            System.out.println(reservation);
        
           
    }
}
}