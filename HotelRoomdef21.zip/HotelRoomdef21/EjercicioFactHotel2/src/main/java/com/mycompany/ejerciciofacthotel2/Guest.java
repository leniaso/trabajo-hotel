/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejerciciofacthotel2;

/**
 *
 * @author maria
 */
public class Guest {
    public String guestName;
    public int tipeId;
    public String id;
    public int cc;

    public Guest() {
    }

    public Guest(String name, int tipeId, String id, int cc) {
        this.guestName = name;
        this.tipeId = tipeId;
        this.id = id;
        this.cc = cc;
    }

    public String getName() {
        return guestName;
    }

    public void setName(String name) {
        this.guestName = name;
    }

    public int getTipeId() {
        return tipeId;
    }

    public void setTipeId(int tipeId) {
        this.tipeId = tipeId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getCc() {
        return cc;
    }

    public void setCc(int cc) {
        this.cc = cc;
    }
    

}