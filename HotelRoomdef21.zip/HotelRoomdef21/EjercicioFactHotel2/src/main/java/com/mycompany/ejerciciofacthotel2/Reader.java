/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejerciciofacthotel2;

/**
 *
 * @author maria
 */
import java.util.*;

public class Reader {
    Scanner sc = new Scanner(System.in);
    
    
        public String readString(String mensaje){
        System.out.println(mensaje);
        String dato = sc.nextLine();
        return dato;
        
    
    }
    public int readAndValidInt(String mensaje) {
        int dato;
        do {
            System.out.print(mensaje);
            while (!sc.hasNextInt()) {
                System.out.println("Valor no válido");
                sc.next();
                System.out.println("Debe ser número entero positivo. Intente nuevamente: ");
            }
            dato = sc.nextInt();
            if(dato < 0){
                System.out.println("El número debe ser positivo");
            }
        } while (dato < 0);
        return dato;
    }
    
    public int readAndValidInt2(String mensaje, int min, int max) {
    int dato;
    do {
        System.out.print(mensaje);
        while (!sc.hasNextInt()) {
            System.out.println("Valor no válido. Intente nuevamente: ");
            sc.next(); // Descarta la entrada no válida
        }
        dato = sc.nextInt();
         sc.nextLine();
        if (dato < min || dato > max) {
            System.out.println("Por favor, ingrese un número entre " + min + " y " + max + ".");
          
        }
    } while (dato < min || dato > max); // Valida que el dato esté dentro del rango permitido
    return dato;
}
    
    public char readChar(String mensaje) {
        System.out.print(mensaje);
        char caracter = sc.next().charAt(0); // Lee el primer carácter de la entrada del usuario
        sc.nextLine(); // Consumir el salto de línea pendiente después de la entrada del usuario
        return caracter;
    }
    
    public  int readAndValidInt3(String mensaje, int min, int max, Lists list) {
    int dato;
   boolean vali;
   
   
    do {
        System.out.print(mensaje);
        while (!sc.hasNextInt()) {
            System.out.println("Valor no válido. Intente nuevamente: ");
            sc.next(); // Descarta la entrada no válida
        }
         dato = sc.nextInt();
         vali = list.getterRoom(dato);
         sc.nextLine();

        if (dato < min || dato > max) {
            System.out.println("Por favor, ingrese un número entre " + min + " y " + max + ".");
         
                 
        }
        if(vali==false){
            System.out.println("lo siento pero tu habitacion ya se encuentra ocupada, por favor escoge otra");
        }
            
    } while (dato < min || dato > max || vali==false); // Valida que el dato esté dentro del rango permitido
    return dato;
}
}

