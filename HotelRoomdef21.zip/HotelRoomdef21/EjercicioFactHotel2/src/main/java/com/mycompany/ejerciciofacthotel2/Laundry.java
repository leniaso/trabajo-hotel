/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejerciciofacthotel2;

/**
 *
 * @author maria
 */
public class Laundry { 
    public int askL;
    public int totalLaundry;
    public int priceService = 50000;
    public int numberWashes;
    
   
    public Laundry() {
    }

    public Laundry(int askL, int totalLaundry) {
        this.askL = askL;
        this.totalLaundry = totalLaundry;
    }
 public int getPriceService() {
        return priceService;
    }

    public void setPriceService(int priceService) {
        this.priceService = priceService;
    }

    public int getNumberWashes() {
        return numberWashes;
    }

    public void setNumberWashes(int numberWashes) {
        this.numberWashes = numberWashes;
    }
    public int getAskL() {
        return askL;
    }

    public void setAskL(int askL) {
        this.askL = askL;
    }

    public int getTotalLaundry() {
        return totalLaundry;
    }

    public void setTotalLaundry(int totalLaundry) {
        this.totalLaundry = totalLaundry;
    }

    @Override
    public String toString() {
        return "Costo total de lavandería: " + totalLaundry + ", con precio por servicio de " + priceService + " y un numero de lavadas " + numberWashes;
    }
    
    
}
