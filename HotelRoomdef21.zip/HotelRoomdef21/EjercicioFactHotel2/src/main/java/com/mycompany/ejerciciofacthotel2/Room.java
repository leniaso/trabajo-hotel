/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejerciciofacthotel2;

/**
 *
 * @author maria
 */

import java.io.FileWriter;
import java.io.IOException;


public class Room {
    

    
    
    
    public int nmrRoom;
    public int location;
    public int price;
    public int timeH;
    public int damage;
    
    public Room() {
    }

    public Room(int nmrRoom,int location, int price, int timeH, int damage) {
        this.nmrRoom = nmrRoom;
        this.location = location;
        this.price = price;
        this.timeH = timeH;
        this.damage = damage;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getTimeH() {
        return timeH;
    }

    public void setTimeH(int timeH) {
        this.timeH = timeH;
    }

    public int getNmrRoom() {
        return nmrRoom;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public void setNmrRoom(int nmrRoom) {
        this.nmrRoom = nmrRoom;
    }

    public int getLocation() {
        return location;
    }

    public void setLocation(int location) {
        this.location = location;
    }
@Override
    public String toString() {
        return "Habitación nro: " + nmrRoom +" \n con tarifa por noche de: " + price + " pesos \n ocupada en un tiempo de: " + timeH + " noche(s)";
    }
    
}