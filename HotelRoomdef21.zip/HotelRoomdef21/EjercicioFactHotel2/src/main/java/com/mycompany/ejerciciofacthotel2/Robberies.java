/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejerciciofacthotel2;

/**
 *
 * @author maria
 */
public class Robberies {
    private boolean wereRobberies;
    private double costRobberies;

    public Robberies() {
        this.wereRobberies = false;
        this.costRobberies = 0.0;
    }

    public void registerRobberies(boolean wereRobberies, double costRobberies) {
        this.wereRobberies = wereRobberies;
        if (wereRobberies) {
            this.costRobberies = costRobberies;
        } else {
            this.costRobberies = 0.0;
        }
    }

    public boolean isWereRobberies() {
        return wereRobberies;
    }

    public double getCostRoberies() {
        return costRobberies;
    }
}