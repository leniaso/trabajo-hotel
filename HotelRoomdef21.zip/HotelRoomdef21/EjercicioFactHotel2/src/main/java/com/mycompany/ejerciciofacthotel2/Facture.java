/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejerciciofacthotel2;

import java.util.*;
import java.io.FileWriter;
import java.io.IOException;


public class Facture {
   
     private Reader read = new Reader();
    private static int tipeId;
    private static String id;
    private static int cc;
    private static int preguntar;
    private List<String> Reservation;

    private Room room = new Room(); // Inicialmente, daños es 0
    private Bill facture = new Bill();
    private Robberies roberies = new Robberies();
    private Incidents incidents = new Incidents();
    private Laundry laundry1 = new Laundry();
    private Lists listsClients = new Lists();
    private Lists listRooms = new Lists();
    
    
   
    

    
 
    
    

    public void dataCollection() {
        // Solicita los datos del cliente y de la habitación
        facture.setBillNo((int) (Math.random() * 100000));
        facture.setGuestName(read.readString("Nombre completo del cliente: "));
        String clientName = facture.getGuestName();
        listsClients.addClient(clientName);
        facture.setTipeId(read.readAndValidInt2("Ingrese 1 si es CC, 2 si es CE, 3 si es PAS: ", 1, 3));
        tipeId = facture.getTipeId();
        valTipe();
        room.setNmrRoom(read.readAndValidInt3("Ingrese el número de la habitación: ", 1, 399, listRooms));
        int roomNumber = room.getNmrRoom();
        String Category= getCategory(roomNumber);
        listRooms.ResgisterRoom(roomNumber);
        
        room.setTimeH(read.readAndValidInt("Ingrese el tiempo de estadía en noches: "));
        meIncidents();
        int roomPrice = CalculatePriceRoom(roomNumber);
        room.setPrice(roomPrice * room.getTimeH());
        preguntar = read.readAndValidInt("Ingrese (1) si lavó, (2) si no lavó: ");
        chargeLaundry();
        String reservation=BookOfGuest(roomNumber, clientName, Category );
        Reservation.add(reservation);
    }
    
   


    public void meIncidents() {
        char responseRobberies = read.readChar("¿Hubo robos durante la estancia? (s/n): ");
        if (responseRobberies == 's' || responseRobberies == 'S') {
            int robberiesCost = read.readAndValidInt("Ingrese el costo de los robos: ");
            roberies.registerRobberies(true, robberiesCost);
        }
        addIncidents();
    }
    
    public void chargeLaundry() {
        if (clean()) {
            laundry1.setNumberWashes(read.readAndValidInt("Ingrese el número de veces que usó el servicio de lavandería: "));
            laundry1.setTotalLaundry(laundry1.getNumberWashes() * laundry1.getPriceService());
        }
    }

    public boolean clean() {
        return preguntar == 1;
    }
    
    public void valTipe(){
        if (tipeId == 1){
           cc = read.readAndValidInt("Ingrese su número de documento: ");
           facture.setCc(cc);
            
        }
        else {
           id = read.readString("Ingrese su número de documento: ");
           facture.setId(id);
           
        }
    }
    
   public void addIncidents() {
        while (true) {
            int IncidentTipe = read.readAndValidInt2(
                    "Ingrese el tipo de incidente (1 para daño leve, 2 para daño moderado, 3 para daño severo, 4 si no hay daños): ", 1, 4);
            if (IncidentTipe == 4 ) {
                System.out.println("No se registraron mas daños daños.");
                break;
            }
            if(IncidentTipe>=1 && IncidentTipe<=3){
                System.out.println("deseas agregar algun otro tipo de daño");
            }
            double IncidentCost = calculateIncidentCost(IncidentTipe);
            incidents.registerIncident(IncidentTipe, IncidentCost);
        }
    }
   
   public double calculateIncidentCost(int incidentTipe) {
        switch (incidentTipe) {
            case 1:
                return 30000; // Daño leve
            case 2:
                return 40000; // Daño moderado
            case 3:
                return 60000; // Daño severo
            default:
                return 0; // No hay daños
        }
    }

    private int CalculatePriceRoom(int roomNumber){
        int s1 = (roomNumber / 100);
        return switch (s1) {
            case 0 -> 150000; // habitación individual
            case 1 -> 230000; // habitación doble
            case 2 -> 340000; // habitación familiar
            case 3 -> 500000; // habitación suite
            default -> 0;
        };
    }
    
    public void incidentsAndRobberies(){
        if (incidents.CalculateTotalIncidentsCost() != 0){
            printMesagge("Valor a pagar por incidentes ocasionados: " + incidents.CalculateTotalIncidentsCost());
        }
        if (roberies.getCostRoberies() != 0){
            printMesagge("Valor a pagar por robos: " + roberies.getCostRoberies());
        }
    }
    
    public void printFacture(){     
        double costoTotal = room.getPrice()+laundry1.getTotalLaundry() 
                + incidents.CalculateTotalIncidentsCost() + roberies.getCostRoberies();
        printMesagge(facture.toString());
        printMesagge(room.toString());
        printMesagge(laundry1.toString());
        incidentsAndRobberies();
        
        printMesagge("Costo total a pagar: "+ costoTotal);
    }

    
    
    private void printMesagge(String cadena){
        System.out.println(cadena);
    }
        public String continuefact(){
         read.sc.nextLine();
         String val=read.readString("deseas realizar otra facturacion, oprime 1 para si, y cualquier otro boton para no: ");
         
        return val;
        
}

  public Facture() {
        listsClients = new Lists();
        listRooms = new Lists();
        listRooms.initializeListRooms();
        Reservation = new ArrayList<>();
    }
    
    private static String getCategory(int roomNumber) {
        int index=roomNumber/100;
        switch (index) {
            case 0:
                return "Individual";
            case 1:
                return "Doble";
            case 2:
                return "Familiar";
            case 3:
                return "Suite";
            default:
                return "Desconocida";
        }
    }
    private static String BookOfGuest(int roomNumber, String GuestName, String Category){
        String reserve="el cliente "+ GuestName+ " \n "
                + " Se encuentra en la habitacion " + roomNumber + " \n "
                + " categoria " + Category +
                "\n";
         return reserve;
               
    }

    public List<String> getReservation() {
        return Reservation;
    }
}
