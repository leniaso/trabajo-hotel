/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejerciciofacthotel2;

import java.util.*;

public class Lists{
    private List<String> listsClients;
    private ArrayList<Boolean> listRooms;
    public Lists(){
         listsClients=new ArrayList<>();
         listRooms= new ArrayList<>();
         
     }
    public void addClient(String nombreHuesped){
        listsClients.add(nombreHuesped);
    }
    
    public List<String> obtainGuestList(){
        return listsClients;
    }
    public void ResgisterRoom(int roomNumber){
        listRooms.add(roomNumber, false);
    }

    public  ArrayList<Boolean> getListRooms() {
        return listRooms;
    }
  
    public void setListRooms(ArrayList<Boolean> listRooms) {
        this.listRooms = listRooms;
    }

    
    
     public  boolean getterRoom(int numberRoom){
        return listRooms.get(numberRoom);
    }
     public void initializeListRooms() {
        listRooms = new ArrayList<>(Collections.nCopies(400, true));
     }
}
