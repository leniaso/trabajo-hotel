/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejerciciofacthotel2;

/**
 *
 * @author maria
 */
import java.util.ArrayList;
import java.util.List;

public class Incidents implements IIncidents {
    private List<Incident> IncidentsGen;

    public Incidents() {
        this.IncidentsGen = new ArrayList<>();
    }

    @Override
    public void registerIncident(int tipo, double costo) {
        Incident incident = new Incident(tipo, costo);
        IncidentsGen.add(incident);
    }
    
    @Override
    public double CalculateTotalIncidentsCost() {
    double costoTotal = 0;
    for (Incident incident : IncidentsGen) {
        costoTotal += incident.getCostI();
    }
    return costoTotal;
}


    // Clase interna para representar un incidente
    private class Incident {
        private int tipeI;
        private double costI;

        public Incident(int tipeI, double costI) {
            this.tipeI = tipeI;
            this.costI = costI;
        }

        // Getter para obtener el costo del incidente
        public double getCostI() {
            return costI;
        }
    }
}