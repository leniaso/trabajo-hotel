package com.mycompany.ejerciciofacthotel2;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author Diego Rendón
 */
public interface IIncidents {
    void registerIncident(int tipo, double costo);
    double CalculateTotalIncidentsCost();
    
}
